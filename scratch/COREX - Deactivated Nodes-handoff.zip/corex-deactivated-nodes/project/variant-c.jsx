// Variant C — "Ghost Silhouette + Inspector Call-out"
// The most radical: deactivated nodes become a thin, translucent silhouette of the
// original card (same size, same port positions, same category stripe — but muted,
// with content replaced by a single centered "ghost" state).
// An inline inspector-style callout next to the selected ghost shows the add-on
// required and a primary "Activate" button. The idea: ghosts feel like placeholders,
// not broken nodes — "we know what goes here, we just need to load it."

function GhostNode({ title, cat = "physics", left, top, selected, subnodeHint }) {
  const catColor = {
    core: "var(--cat-core)", io: "var(--cat-io)",
    physics: "var(--cat-physics)", logic: "var(--cat-logic)",
    hpc: "var(--cat-hpc)", default: "var(--cat-default)",
  }[cat];
  return (
    <div style={{
      position: "absolute", left, top, width: 230, height: 120,
      background: "rgba(27,29,34,0.55)",
      border: selected ? "2px solid #60cdff" : "1.5px dashed #4a4f5a",
      borderRadius: 8,
      boxShadow: "0 1px 0 rgba(0,0,0,.3), 0 6px 18px rgba(0,0,0,.25)",
      fontFamily: "var(--font-ui)",
      overflow: "hidden",
    }}>
      {/* Category stripe kept but faded */}
      <div style={{
        position: "absolute", left: 0, top: 0, bottom: 0, width: 3,
        background: catColor, opacity: 0.35,
      }}/>

      {/* Top title sliver */}
      <div style={{
        padding: "7px 10px 6px 13px",
        display: "flex", alignItems: "center", gap: 8,
        borderBottom: "1px dashed #3a3d45",
      }}>
        <LockIcon size={11} color="#6b7280"/>
        <span style={{
          font: "600 12px/1.1 var(--font-ui)",
          color: "#8a93a3", flex: 1,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{title}</span>
      </div>

      {/* Ghost body */}
      <div style={{
        padding: "14px 12px",
        display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        gap: 6, height: 82,
      }}>
        <PlugIcon size={18} color="#60cdff"/>
        <div style={{ font: "10.5px var(--font-ui)", color: "#8a93a3", letterSpacing: 0.4, textTransform: "uppercase" }}>
          Add-on required
        </div>
        {subnodeHint && (
          <div style={{ font: "10px var(--font-mono)", color: "#60606a" }}>{subnodeHint}</div>
        )}
      </div>

      {/* Ghost ports — outline only */}
      <div style={{
        position: "absolute", left: -6, top: 36,
        width: 10, height: 10, borderRadius: "50%",
        background: "transparent",
        border: "1.5px dashed #5a606c",
      }}/>
      <div style={{
        position: "absolute", right: -6, top: 36,
        width: 10, height: 10, borderRadius: "50%",
        background: "transparent",
        border: "1.5px dashed #5a606c",
      }}/>
    </div>
  );
}

function VariantC() {
  return (
    <Canvas>
      {/* Edges — dashed + muted to/from ghosts */}
      <Edge from={[210, 190]} to={[405, 200]} color="#4a4f5a" dash />
      <Edge from={[625, 200]} to={[820, 190]} color="#4a4f5a" dash />

      {/* Active */}
      <div style={{ position: "absolute", left: 30, top: 130 }}>
        <NodeCard
          title="DPF Data Source"
          cat="io"
          rows={[{ l: "File", v: "rotor.rst" }, { l: "Time step", v: "last" }]}
        />
      </div>

      <GhostNode title="Modal Projection" cat="physics" left={405} top={140} selected subnodeHint="4 params · 2 ports"/>
      <GhostNode title="Harmonic Response" cat="physics" left={820} top={130} subnodeHint="2 params · 2 ports"/>

      {/* Active */}
      <div style={{ position: "absolute", left: 30, top: 340 }}>
        <NodeCard
          title="Signal Generator"
          cat="core"
          rows={[{ l: "Freq (Hz)", v: "60.0" }, { l: "Amplitude", v: "1.0" }]}
        />
      </div>

      {/* Inspector call-out anchored to selected ghost */}
      <div style={{
        position: "absolute", left: 405, top: 285,
        width: 360,
        background: "var(--inspector-card-bg)",
        border: "1px solid var(--inspector-selected-border)",
        borderRadius: 8,
        boxShadow: "var(--shadow-popup)",
        fontFamily: "var(--font-ui)",
      }}>
        {/* Pointer triangle up */}
        <div style={{
          position: "absolute", left: 90, top: -7, width: 12, height: 12,
          background: "var(--inspector-card-bg)",
          borderTop: "1px solid var(--inspector-selected-border)",
          borderLeft: "1px solid var(--inspector-selected-border)",
          transform: "rotate(45deg)",
        }}/>
        <div style={{
          padding: "8px 12px",
          background: "var(--inspector-section-header-bg)",
          borderBottom: "1px solid var(--border)",
          borderRadius: "8px 8px 0 0",
          display: "flex", alignItems: "center", gap: 8,
        }}>
          <LockIcon size={12} color="var(--accent)"/>
          <span style={{ font: "600 11px/1 var(--font-ui)", color: "var(--muted-fg)", textTransform: "uppercase", letterSpacing: 0.5 }}>
            Inactive node
          </span>
          <span style={{ marginLeft: "auto", font: "10.5px var(--font-mono)", color: "var(--muted-fg)", opacity: 0.7 }}>id: 4a7c</span>
        </div>
        <div style={{ padding: "10px 12px" }}>
          <div style={{ font: "600 14px/1.2 var(--font-ui)", color: "var(--panel-title-fg)", marginBottom: 2 }}>
            Modal Projection
          </div>
          <div style={{ font: "11px var(--font-mono)", color: "var(--muted-fg)", marginBottom: 10 }}>
            physics.modal.ModalProjection
          </div>
          <div style={{
            display: "flex", gap: 8, alignItems: "center",
            padding: "8px 10px",
            background: "#1a1c21", border: "1px solid var(--border)",
            borderRadius: 4, marginBottom: 10,
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: 6,
              background: "rgba(96,205,255,0.12)",
              border: "1px solid rgba(96,205,255,0.4)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <PlugIcon size={14} color="var(--accent)"/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: "12px var(--font-ui)", color: "var(--app-fg)" }}>modal-physics</div>
              <div style={{ font: "10.5px var(--font-mono)", color: "var(--muted-fg)" }}>v2.1.0 · installed · not loaded</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <button style={{
              flex: 1,
              background: "var(--accent-strong)", color: "#fff",
              border: "1px solid var(--accent-strong)",
              padding: "6px 10px", borderRadius: 3,
              font: "600 12px var(--font-ui)", cursor: "pointer",
              display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6,
            }}>
              <PlugIcon size={11} color="#fff"/> Activate add-on
            </button>
            <button style={{
              background: "var(--panel-alt-bg)", color: "var(--app-fg)",
              border: "1px solid var(--border)",
              padding: "6px 10px", borderRadius: 3,
              font: "500 12px var(--font-ui)", cursor: "pointer",
            }}>
              Manage…
            </button>
          </div>
        </div>
      </div>

      {/* Canvas hint */}
      <div style={{
        position: "absolute", top: 12, left: 14,
        color: "var(--muted-fg)", fontSize: 11.5,
        background: "rgba(0,0,0,0.25)", padding: "4px 10px", borderRadius: 3,
      }}>
        2 inactive nodes · click a ghost to activate
      </div>
    </Canvas>
  );
}

Object.assign(window, { VariantC, GhostNode });
