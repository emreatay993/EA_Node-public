// Shared node-card renderer for the mockup canvas.
// Each variant picks which "deactivated" treatment to apply.

function Port({ side = "l", top, kind = "yellow" }) {
  const style = {
    position: "absolute",
    [side === "l" ? "left" : "right"]: -6,
    top,
    width: 10, height: 10, borderRadius: "50%",
    background: "var(--node-port-fill)",
    border: "2px solid var(--node-port-border)",
    boxShadow: "0 0 0 4px var(--node-port-ring-fill), 0 0 0 5px var(--node-port-ring-border)",
  };
  if (kind === "dim") {
    style.background = "#4a4f5a";
    style.border = "2px solid #5a606c";
    style.boxShadow = "none";
    style.opacity = 0.55;
  }
  return <div style={style} />;
}

/**
 * Base node card.
 * Props: title, sub, cat, rows=[{l,v}], running (show run-badge), selected, style
 */
function NodeCard({
  title, sub, cat = "physics", rows = [], badge, selected,
  width = 230, style = {}, children, portKind = "yellow",
}) {
  const catColor = {
    core: "var(--cat-core)",
    io: "var(--cat-io)",
    physics: "var(--cat-physics)",
    logic: "var(--cat-logic)",
    hpc: "var(--cat-hpc)",
    default: "var(--cat-default)",
  }[cat];

  return (
    <div style={{
      position: "relative", width,
      background: "var(--node-card-bg)",
      border: selected ? "2px solid var(--node-card-selected-border)" : "1px solid var(--node-card-border)",
      borderRadius: 8,
      boxShadow: "0 1px 0 rgba(0,0,0,.4), 0 6px 18px rgba(0,0,0,.35)",
      fontFamily: "var(--font-ui)",
      ...style,
    }}>
      {/* Header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "8px 10px",
        background: "var(--node-header-bg)",
        borderBottom: "1px solid var(--node-card-border)",
        borderLeft: `3px solid ${catColor}`,
        borderTopLeftRadius: 7, borderTopRightRadius: 7,
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" style={{ color: "var(--node-header-fg)", opacity: 0.9 }}>
          <path d="M4 7h16M4 12h10M4 17h16" strokeLinecap="round"/>
        </svg>
        <span style={{ font: "600 13px/1.1 var(--font-ui)", color: "var(--node-header-fg)", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{title}</span>
        {badge}
        {sub && <span style={{ font: "10.5px var(--font-mono)", color: "var(--muted-fg)", opacity: 0.7 }}>{sub}</span>}
      </div>
      {/* Rows */}
      <div style={{ padding: 6, display: "grid", gap: 5 }}>
        {rows.map((r, i) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "4px 7px",
            background: "var(--node-inline-row-bg)",
            border: "1px solid var(--node-inline-row-border)",
            borderRadius: 4,
          }}>
            <span style={{ fontSize: 11, color: "var(--node-inline-label-fg)" }}>{r.l}</span>
            <span style={{ font: "11px/1 var(--font-mono)", color: "var(--input-fg)" }}>{r.v}</span>
          </div>
        ))}
      </div>
      {/* Ports */}
      <Port side="l" top={36} kind={portKind} />
      <Port side="r" top={36} kind={portKind} />
      {children}
    </div>
  );
}

// Edge between two nodes (simple svg curve)
function Edge({ from, to, color = "var(--muted-fg)", dash = false, width = 1.5 }) {
  const [x1, y1] = from, [x2, y2] = to;
  const dx = Math.max(40, (x2 - x1) * 0.5);
  const d = `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
  return (
    <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", overflow: "visible" }}>
      <path d={d} stroke={color} strokeWidth={width} fill="none" strokeDasharray={dash ? "4 4" : undefined} strokeLinecap="round"/>
    </svg>
  );
}

// Canvas backdrop with COREX grid
function Canvas({ children, style = {} }) {
  return (
    <div style={{
      position: "absolute", inset: 0,
      background: "var(--canvas-bg)",
      backgroundImage: `
        linear-gradient(var(--canvas-minor-grid) 1px, transparent 1px),
        linear-gradient(90deg, var(--canvas-minor-grid) 1px, transparent 1px),
        linear-gradient(var(--canvas-major-grid) 1px, transparent 1px),
        linear-gradient(90deg, var(--canvas-major-grid) 1px, transparent 1px)`,
      backgroundSize: "16px 16px, 16px 16px, 96px 96px, 96px 96px",
      overflow: "hidden",
      ...style,
    }}>
      {children}
    </div>
  );
}

// Small lock icon used by several variants
function LockIcon({ size = 12, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="11" width="16" height="10" rx="2"/>
      <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
    </svg>
  );
}

function PlugIcon({ size = 12, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 2v4M15 2v4"/>
      <path d="M6 6h12v6a6 6 0 0 1-12 0z"/>
      <path d="M12 18v4"/>
    </svg>
  );
}

function WarnIcon({ size = 12, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 3l10 18H2z"/>
      <path d="M12 10v5M12 18h.01"/>
    </svg>
  );
}

Object.assign(window, { NodeCard, Port, Edge, Canvas, LockIcon, PlugIcon, WarnIcon });
