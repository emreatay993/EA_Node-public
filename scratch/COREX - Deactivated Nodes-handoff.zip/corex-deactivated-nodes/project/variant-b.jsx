// Variant B — "Locked Chip in Header"
// No overlay, no filter. The card keeps its silhouette but:
//   • Header fill swaps to a muted slate (not the warm header bg)
//   • Category accent stripe is replaced by a 3px dashed neutral stripe
//   • A "LOCKED" pill appears in the header
//   • Inline rows collapse into a single "Locked — add-on required" strip
//   • Ports show a tiny lock glyph instead of the warm yellow handle
// Keeps the visual "mass" close to normal so spatial memory of the graph is preserved,
// but the state is unambiguous on any zoom level.

function LockedPort({ side = "l", top }) {
  return (
    <div style={{
      position: "absolute",
      [side === "l" ? "left" : "right"]: -9,
      top: top - 4,
      width: 18, height: 18, borderRadius: "50%",
      background: "#2a2d34",
      border: "1.5px solid #5a606c",
      display: "flex", alignItems: "center", justifyContent: "center",
      color: "#8a93a3",
    }}>
      <LockIcon size={9} color="#8a93a3"/>
    </div>
  );
}

function LockedNode({ title, rows, addon, left, top, selected }) {
  return (
    <div style={{
      position: "absolute", left, top, width: 230,
      background: "var(--node-card-bg)",
      border: selected ? "2px solid #8a93a3" : "1px solid var(--node-card-border)",
      borderRadius: 8,
      boxShadow: "0 1px 0 rgba(0,0,0,.4), 0 6px 18px rgba(0,0,0,.35)",
      fontFamily: "var(--font-ui)",
    }}>
      {/* Muted header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "8px 10px",
        background: "#25272d",
        borderBottom: "1px solid var(--node-card-border)",
        borderLeft: "3px dashed #6b7280",
        borderTopLeftRadius: 7, borderTopRightRadius: 7,
      }}>
        <LockIcon size={13} color="#b0b7c3"/>
        <span style={{
          font: "600 13px/1.1 var(--font-ui)",
          color: "#b0b7c3", flex: 1,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{title}</span>
        <span style={{
          font: "600 9px/1 var(--font-ui)", letterSpacing: 0.6, textTransform: "uppercase",
          background: "#3a3d45", color: "#d0d5de",
          padding: "3px 6px", borderRadius: 3,
        }}>Locked</span>
      </div>

      {/* Collapsed body */}
      <div style={{ padding: 8, display: "grid", gap: 6 }}>
        <div style={{
          padding: "6px 8px",
          background: "#1a1c21",
          border: "1px dashed #4a4f5a",
          borderRadius: 4,
          display: "flex", alignItems: "center", gap: 8,
        }}>
          <PlugIcon size={11} color="#8a93a3"/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 10.5, color: "#8a93a3", letterSpacing: 0.3, textTransform: "uppercase" }}>Requires add-on</div>
            <div style={{ font: "11.5px var(--font-mono)", color: "#d0d5de", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{addon}</div>
          </div>
        </div>
        <div style={{ fontSize: 10.5, color: "#6b7280", padding: "0 2px", display: "flex", justifyContent: "flex-end" }}>
          <span style={{ color: "#60cdff", cursor: "pointer" }}>Load…</span>
        </div>
      </div>

      <LockedPort side="l" top={30} />
      <LockedPort side="r" top={30} />
    </div>
  );
}

function VariantB() {
  return (
    <Canvas>
      <Edge from={[210, 180]} to={[405, 167]} color="var(--muted-fg)" dash />
      <Edge from={[625, 167]} to={[820, 180]} color="var(--muted-fg)" dash />
      <Edge from={[820, 220]} to={[960, 310]} color="var(--edge-warning)" dash />

      {/* Active */}
      <div style={{ position: "absolute", left: 30, top: 130 }}>
        <NodeCard
          title="DPF Data Source"
          cat="io"
          rows={[{ l: "File", v: "rotor.rst" }, { l: "Time step", v: "last" }]}
        />
      </div>

      <LockedNode
        title="Modal Projection"
        addon="modal-physics@2.1"
        rows={4}
        left={405} top={140}
        selected
      />

      <LockedNode
        title="Harmonic Response"
        addon="modal-physics@2.1"
        rows={2}
        left={820} top={140}
      />

      {/* Regular downstream node */}
      <div style={{ position: "absolute", left: 960, top: 290 }}>
        <NodeCard
          title="Export CSV"
          cat="core"
          rows={[{ l: "Path", v: "out/*.csv" }]}
        />
      </div>

      {/* Status ribbon */}
      <div style={{
        position: "absolute", top: 12, left: 14, right: 14,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        gap: 8,
      }}>
        <div style={{
          color: "var(--muted-fg)", fontSize: 11.5,
          background: "rgba(0,0,0,0.25)", padding: "4px 10px", borderRadius: 3,
          display: "inline-flex", alignItems: "center", gap: 6,
        }}>
          <LockIcon size={11} color="var(--muted-fg)"/>
          2 locked nodes · 1 add-on missing
        </div>
        <div style={{
          background: "var(--accent-strong)", color: "#fff",
          padding: "5px 11px", borderRadius: 3,
          font: "600 11px var(--font-ui)",
          display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer",
        }}>
          <PlugIcon size={11} color="#fff"/> Load missing add-ons
        </div>
      </div>
    </Canvas>
  );
}

Object.assign(window, { VariantB, LockedNode });
