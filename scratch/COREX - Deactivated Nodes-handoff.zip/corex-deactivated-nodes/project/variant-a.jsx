// Variant A — "Hatched Quarantine"
// Diagonal SVG hatch overlay across the whole card + heavy desaturation.
// A corner "MISSING ADD-ON" badge in the header's accent stripe area.
// Ports are dimmed (grey, no glow) so drag-to-connect visually reads as unavailable.
// Selected border kept as an idle dashed outline to hint "you CAN click it to inspect".

function VariantA() {
  const hatchId = "hatchA";
  return (
    <Canvas>
      {/* Edges (behind nodes) */}
      <Edge from={[210, 190]} to={[405, 190]} color="var(--muted-fg)" dash />
      <Edge from={[625, 190]} to={[820, 190]} color="var(--edge-warning)" />

      {/* Active upstream node (normal) */}
      <div style={{ position: "absolute", left: 30, top: 130 }}>
        <NodeCard
          title="DPF Data Source"
          cat="io"
          rows={[{ l: "File", v: "rotor.rst" }, { l: "Time step", v: "last" }]}
        />
      </div>

      {/* DEACTIVATED node — middle */}
      <div style={{ position: "absolute", left: 405, top: 130, width: 230, height: 140 }}>
        <NodeCard
          title="Modal Projection"
          cat="physics"
          portKind="dim"
          rows={[
            { l: "Modes", v: "— — —" },
            { l: "Basis", v: "— — —" },
            { l: "Normalize", v: "—" },
          ]}
          style={{
            filter: "grayscale(0.9) brightness(0.75)",
            borderStyle: "dashed",
            borderColor: "#5a606c",
          }}
        />

        {/* Diagonal hatch overlay */}
        <svg style={{ position: "absolute", inset: 0, width: 230, borderRadius: 8, pointerEvents: "none" }}>
          <defs>
            <pattern id={hatchId} width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
              <line x1="0" y1="0" x2="0" y2="8" stroke="#e8a838" strokeWidth="1" opacity="0.22"/>
            </pattern>
            <clipPath id="clipA">
              <rect x="0" y="0" width="230" height="140" rx="8"/>
            </clipPath>
          </defs>
          <rect width="230" height="140" fill={`url(#${hatchId})`} clipPath="url(#clipA)"/>
        </svg>

        {/* Corner "MISSING ADD-ON" ribbon */}
        <div style={{
          position: "absolute", top: -1, right: -1,
          background: "#3a2b1f",
          border: "1px solid #e8a838",
          borderTopRightRadius: 7, borderBottomLeftRadius: 6,
          color: "#e8a838",
          font: "600 9.5px/1 var(--font-ui)",
          letterSpacing: 0.6,
          textTransform: "uppercase",
          padding: "3px 7px",
          display: "flex", alignItems: "center", gap: 5,
        }}>
          <WarnIcon size={10} color="#e8a838"/>
          Add-on not loaded
        </div>
      </div>

      {/* Downstream — also deactivated because it depends on the same pkg */}
      <div style={{ position: "absolute", left: 820, top: 130, width: 230, height: 140 }}>
        <NodeCard
          title="Harmonic Response"
          cat="physics"
          portKind="dim"
          rows={[
            { l: "Freq (Hz)", v: "— — —" },
            { l: "Damping", v: "—" },
          ]}
          style={{
            filter: "grayscale(0.9) brightness(0.75)",
            borderStyle: "dashed",
            borderColor: "#5a606c",
          }}
        />
        <svg style={{ position: "absolute", inset: 0, width: 230, borderRadius: 8, pointerEvents: "none" }}>
          <rect width="230" height="140" fill={`url(#${hatchId})`} clipPath="url(#clipA)"/>
        </svg>
        <div style={{
          position: "absolute", top: -1, right: -1,
          background: "#3a2b1f", border: "1px solid #e8a838",
          borderTopRightRadius: 7, borderBottomLeftRadius: 6,
          color: "#e8a838",
          font: "600 9.5px/1 var(--font-ui)", letterSpacing: 0.6, textTransform: "uppercase",
          padding: "3px 7px", display: "flex", alignItems: "center", gap: 5,
        }}>
          <WarnIcon size={10} color="#e8a838"/>
          Add-on not loaded
        </div>
      </div>

      {/* Canvas hint pill */}
      <div style={{
        position: "absolute", top: 12, left: 14,
        color: "var(--muted-fg)", fontSize: 11.5,
        background: "rgba(0,0,0,0.25)", padding: "4px 10px", borderRadius: 3,
      }}>
        2 nodes require <span style={{ color: "#e8a838" }}>modal-physics@2.1</span> — open Add-on Manager to load
      </div>

      {/* Tooltip on hover (static mock) */}
      <div style={{
        position: "absolute", left: 405, top: 285,
        width: 280, background: "var(--panel-alt-bg)",
        border: "1px solid var(--border)", borderRadius: 6,
        boxShadow: "var(--shadow-popup)",
        padding: "10px 12px",
        font: "12px/1.45 var(--font-ui)", color: "var(--app-fg)",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
          <WarnIcon size={12} color="#e8a838"/>
          <span style={{ color: "#e8a838", fontWeight: 600, fontSize: 11.5 }}>Read-only — add-on not loaded</span>
        </div>
        <div style={{ color: "var(--muted-fg)", fontSize: 11.5, marginBottom: 8 }}>
          This node is defined by <span style={{ fontFamily: "var(--font-mono)", color: "var(--app-fg)" }}>modal-physics</span> (v2.1). Load the add-on to edit parameters or run this graph.
        </div>
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          background: "var(--accent-strong)", color: "#fff",
          padding: "4px 10px", borderRadius: 3,
          font: "600 11px var(--font-ui)", cursor: "pointer",
        }}>
          <PlugIcon size={11} color="#fff"/> Load add-on…
        </div>
      </div>
    </Canvas>
  );
}

Object.assign(window, { VariantA });
