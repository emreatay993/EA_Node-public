// Variant 3 — "Quick Toggle Overlay" — keyboard-driven palette
// on a canvas backdrop. Mirrors the graph's quick-insert overlay pattern.
// Fast, dense, Cmd+K-flavored.

function V3_QuickOverlay() {
  const [q, setQ] = React.useState("");
  const [selected, setSelected] = React.useState(0);
  const [rows, setRows] = React.useState(ADDONS);
  const list = rows.filter(r => !q || r.name.toLowerCase().includes(q.toLowerCase())
    || r.cat.toLowerCase().includes(q.toLowerCase())
    || r.id.includes(q.toLowerCase()));
  const toggle = (id) => setRows(rs => rs.map(r => r.id === id
    ? { ...r, enabled: !r.enabled, status: !r.enabled ? "loaded" : "disabled" } : r));

  return (
    <div data-theme="stitch-dark" style={{
      width: 1180, height: 760, position: "relative",
      background: "var(--canvas-bg)",
      backgroundImage: `
        linear-gradient(var(--canvas-minor-grid) 1px, transparent 1px),
        linear-gradient(90deg, var(--canvas-minor-grid) 1px, transparent 1px),
        linear-gradient(var(--canvas-major-grid) 1px, transparent 1px),
        linear-gradient(90deg, var(--canvas-major-grid) 1px, transparent 1px)
      `,
      backgroundSize: "16px 16px, 16px 16px, 96px 96px, 96px 96px",
      fontFamily: "var(--font-ui)", color: "var(--app-fg)", overflow: "hidden",
      border: "1px solid var(--border)",
    }}>
      {/* Faint canvas suggestion - a couple of ghost nodes + toolbar hint */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: 36,
        background: "var(--toolbar-bg)", borderBottom: "1px solid var(--border)",
        display: "flex", alignItems: "center", gap: 6, padding: "0 10px",
        opacity: 0.6,
      }}>
        <img src="assets/corex_app.svg" style={{ width: 14, height: 14 }} />
        <span style={{ fontWeight: 600, fontSize: 12 }}>COREX</span>
        <span style={{ color: "var(--muted-fg)", fontSize: 11, marginLeft: 6 }}>— Workflow A · running</span>
      </div>

      {/* dim overlay */}
      <div style={{
        position: "absolute", top: 37, left: 0, right: 0, bottom: 0,
        background: "rgba(0,0,0,0.45)",
      }} />

      {/* hint caption */}
      <div style={{
        position: "absolute", top: 60, left: "50%", transform: "translateX(-50%)",
        color: "var(--muted-fg)", fontSize: 11.5, letterSpacing: 0.4,
      }}>
        <span style={{
          fontFamily: "var(--font-mono)", padding: "1px 6px", border: "1px solid var(--border)",
          borderRadius: 3, background: "var(--panel-alt-bg)", color: "var(--app-fg)",
        }}>Ctrl</span>
        <span style={{ margin: "0 4px" }}>+</span>
        <span style={{
          fontFamily: "var(--font-mono)", padding: "1px 6px", border: "1px solid var(--border)",
          borderRadius: 3, background: "var(--panel-alt-bg)", color: "var(--app-fg)",
        }}>Shift</span>
        <span style={{ margin: "0 4px" }}>+</span>
        <span style={{
          fontFamily: "var(--font-mono)", padding: "1px 6px", border: "1px solid var(--border)",
          borderRadius: 3, background: "var(--panel-alt-bg)", color: "var(--app-fg)",
        }}>A</span>
        <span style={{ marginLeft: 10 }}>— toggles the Add-on palette anywhere in the editor.</span>
      </div>

      {/* palette */}
      <div style={{
        position: "absolute", top: 100, left: "50%", transform: "translateX(-50%)",
        width: 720, background: "var(--panel-alt-bg)",
        border: "1px solid var(--border)", borderRadius: 6,
        boxShadow: "var(--shadow-popup)", display: "flex", flexDirection: "column",
        maxHeight: 600,
      }}>
        {/* Search bar with context chip */}
        <div style={{
          padding: "8px 10px", borderBottom: "1px solid var(--border)",
          display: "flex", alignItems: "center", gap: 8,
        }}>
          <span style={{
            fontSize: 10, fontWeight: 600, letterSpacing: 0.5,
            color: "var(--accent)", padding: "1px 6px",
            border: "1px solid var(--accent)", borderRadius: 3,
            background: "rgba(96,205,255,0.08)",
          }}>ADD-ONS</span>
          <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>›</span>
          <input
            value={q} onChange={e => { setQ(e.target.value); setSelected(0); }}
            autoFocus
            placeholder="Toggle add-ons, search by name, category, or vendor…"
            style={{
              flex: 1, background: "transparent", border: "none", outline: "none",
              color: "var(--input-fg)", fontSize: 14, fontFamily: "var(--font-ui)",
              padding: "2px 0",
            }} />
          <span style={{ color: "var(--muted-fg)", fontSize: 10.5, fontFamily: "var(--font-mono)" }}>
            {list.length} results
          </span>
        </div>

        {/* rows */}
        <div style={{ overflowY: "auto", padding: "4px 0", maxHeight: 460 }}>
          {list.map((a, i) => {
            const sel = i === selected;
            return (
              <div key={a.id}
                onMouseEnter={() => setSelected(i)}
                onClick={() => toggle(a.id)}
                style={{
                  display: "grid",
                  gridTemplateColumns: "28px 1fr auto auto 60px",
                  alignItems: "center", gap: 10, padding: "5px 12px",
                  background: sel ? "var(--accent-strong)" : "transparent",
                  color: sel ? "#fff" : "var(--app-fg)", cursor: "default",
                }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 3,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: sel ? "#fff" : "var(--node-header-fg)",
                  borderLeft: `2px solid ${catColor(a.category)}`,
                  background: sel ? "rgba(255,255,255,0.08)" : "var(--node-header-bg)",
                }}>
                  <CatIcon cat={a.category} size={12} />
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontSize: 12.5, fontWeight: 500 }}>{a.name}</span>
                    {a.builtin && (
                      <span style={{
                        fontSize: 9, padding: "0 4px", borderRadius: 2,
                        border: `1px solid ${sel ? "rgba(255,255,255,0.35)" : "var(--border)"}`,
                        color: sel ? "rgba(255,255,255,0.9)" : "var(--muted-fg)",
                        letterSpacing: 0.4, fontWeight: 600,
                      }}>BUILT-IN</span>
                    )}
                  </div>
                  <div style={{
                    fontSize: 10.5,
                    color: sel ? "rgba(255,255,255,0.78)" : "var(--muted-fg)",
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  }}>
                    {a.summary}
                  </div>
                </div>
                <span style={{
                  fontSize: 10.5, fontFamily: "var(--font-mono)",
                  color: sel ? "rgba(255,255,255,0.75)" : "var(--muted-fg)",
                }}>{a.cat}</span>
                <span style={{
                  fontSize: 10.5, fontFamily: "var(--font-mono)",
                  color: sel ? "rgba(255,255,255,0.75)" : "var(--muted-fg)",
                }}>v{a.version}</span>
                <div style={{ display: "flex", justifyContent: "flex-end" }}>
                  <div style={{
                    fontSize: 10, padding: "1px 6px", borderRadius: 2, fontWeight: 600,
                    letterSpacing: 0.4,
                    background: a.enabled
                      ? (sel ? "rgba(255,255,255,0.2)" : "rgba(103,212,135,0.14)")
                      : (sel ? "rgba(0,0,0,0.25)" : "var(--panel-alt-bg)"),
                    color: a.enabled
                      ? (sel ? "#fff" : "var(--run-completed)")
                      : (sel ? "rgba(255,255,255,0.8)" : "var(--muted-fg)"),
                    border: `1px solid ${a.enabled
                      ? (sel ? "rgba(255,255,255,0.35)" : "rgba(103,212,135,0.3)")
                      : (sel ? "rgba(255,255,255,0.2)" : "var(--border)")}`,
                  }}>
                    {a.enabled ? "ON" : "OFF"}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* footer hints */}
        <div style={{
          padding: "6px 12px", borderTop: "1px solid var(--border)",
          display: "flex", alignItems: "center", gap: 14,
          fontSize: 10.5, color: "var(--muted-fg)",
          background: "var(--panel-bg)",
        }}>
          <KeyHint keys={["↑", "↓"]} label="Navigate" />
          <KeyHint keys={["↵"]} label="Toggle" />
          <KeyHint keys={["Shift", "↵"]} label="Open details" />
          <KeyHint keys={["."]} label="Filter: enabled only" />
          <KeyHint keys={["Esc"]} label="Close" />
          <span style={{ flex: 1 }} />
          <span>Changes apply on next runtime restart · <span style={{ color: "var(--accent)" }}>Reload now</span></span>
        </div>
      </div>
    </div>
  );
}

function KeyHint({ keys, label }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
      {keys.map((k, i) => (
        <span key={i} style={{
          fontFamily: "var(--font-mono)", fontSize: 9.5, padding: "0px 4px",
          border: "1px solid var(--border)", borderRadius: 2,
          background: "var(--panel-alt-bg)", color: "var(--app-fg)",
        }}>{k}</span>
      ))}
      <span>{label}</span>
    </span>
  );
}

Object.assign(window, { V3_QuickOverlay, KeyHint });
