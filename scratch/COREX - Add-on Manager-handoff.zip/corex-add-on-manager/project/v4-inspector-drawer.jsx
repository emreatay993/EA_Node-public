// Variant 4 — "Inspector Drawer" — master list + rich documentation detail.
// Side list of add-ons (dense, inspector-style) + big right-hand reading pane
// with about, dependencies, changelog, exposed nodes.

function V4_InspectorDrawer() {
  const [rows, setRows] = React.useState(ADDONS);
  const [sel, setSel] = React.useState("ansys-dpf-core");
  const [tab, setTab] = React.useState("about");
  // Track original state to compute "pending restart" count.
  const initialRef = React.useRef(ADDONS.map(a => ({ id: a.id, enabled: a.enabled })));
  const toggle = (id) => setRows(rs => rs.map(r => r.id === id
    ? { ...r, enabled: !r.enabled, status: !r.enabled ? "loaded" : "disabled" } : r));
  const focus = rows.find(r => r.id === sel);
  const pendingRestart = rows.filter(r => {
    const init = initialRef.current.find(x => x.id === r.id);
    return r.restart && init && init.enabled !== r.enabled;
  });
  const focusPending = pendingRestart.some(p => p.id === focus.id);

  // Mock dependents — who depends on the selected
  const dependents = rows.filter(r => r.deps.includes(focus.id.split("-")[0]));

  return (
    <div data-theme="stitch-dark" style={{
      width: 1180, height: 760, background: "var(--app-bg)", color: "var(--app-fg)",
      fontFamily: "var(--font-ui)", fontSize: 12, display: "flex", flexDirection: "column",
      border: "1px solid var(--border)",
    }}>
      {/* Title */}
      <div style={{
        background: "var(--toolbar-bg)", borderBottom: "1px solid var(--border)",
        padding: "8px 14px", display: "flex", alignItems: "center", gap: 10,
      }}>
        <img src="assets/corex_app.svg" style={{ width: 14, height: 14 }} />
        <span style={{ fontWeight: 600, fontSize: 13, color: "var(--panel-title-fg)" }}>
          Manage Add-ons
        </span>
        <span style={{ color: "var(--muted-fg)", fontSize: 11, fontFamily: "var(--font-mono)" }}>
          {rows.filter(r => r.enabled).length} loaded · {rows.length} installed
        </span>
        {pendingRestart.length > 0 && (
          <span style={{
            fontSize: 10.5, padding: "2px 8px", borderRadius: 999,
            background: "rgba(232,168,56,0.14)", border: "1px solid rgba(232,168,56,0.4)",
            color: "var(--edge-warning)", fontWeight: 600, letterSpacing: 0.3,
            display: "inline-flex", alignItems: "center", gap: 5,
          }}>
            <RestartGlyph size={10} /> {pendingRestart.length} pending restart
          </span>
        )}
        <span style={{ flex: 1 }} />
        <button style={tbBtn}>Check for updates</button>
        <button style={tbBtn}>Install from File…</button>
        {pendingRestart.length > 0 && (
          <button style={{
            ...tbBtn, background: "var(--accent-strong)", color: "#fff",
            borderColor: "var(--accent-strong)",
          }}>Restart Runtime</button>
        )}
      </div>

      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "340px 1fr", minHeight: 0 }}>
        {/* List */}
        <div style={{ borderRight: "1px solid var(--border)", background: "var(--panel-bg)",
          display: "flex", flexDirection: "column", minHeight: 0 }}>
          <div style={{ padding: "6px 8px", borderBottom: "1px solid var(--border)",
            display: "flex", gap: 4 }}>
            {["All", "Enabled", "Disabled"].map((t, i) => (
              <button key={t} style={{
                ...tbBtn, flex: 1, justifyContent: "center",
                borderColor: i === 0 ? "var(--accent)" : "var(--border)",
                color: i === 0 ? "var(--accent)" : "var(--app-fg)",
              }}>{t}</button>
            ))}
          </div>
          <div style={{ overflowY: "auto", flex: 1 }}>
            {rows.map(a => (
              <div key={a.id}
                onClick={() => setSel(a.id)}
                style={{
                  padding: "8px 10px 8px 12px",
                  borderBottom: "1px solid var(--border)",
                  background: sel === a.id ? "var(--inspector-selected-bg)" : "transparent",
                  borderLeft: sel === a.id
                    ? `3px solid var(--accent)` : `3px solid transparent`,
                  cursor: "default",
                }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 3,
                    background: "var(--node-header-bg)",
                    borderLeft: `3px solid ${catColor(a.category)}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "var(--node-header-fg)",
                  }}>
                    <CatIcon cat={a.category} size={11} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      fontWeight: 600, fontSize: 12, color: "var(--panel-title-fg)",
                      whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                    }}>{a.name}</div>
                    <div style={{
                      fontSize: 10.5, color: "var(--muted-fg)",
                      fontFamily: "var(--font-mono)", marginTop: 1,
                      display: "flex", alignItems: "center", gap: 6,
                    }}>
                      <span>{a.cat} · v{a.version}</span>
                      {a.restart ? (
                        <span title="Toggling requires runtime restart" style={{
                          display: "inline-flex", alignItems: "center", gap: 3,
                          color: "var(--edge-warning)",
                        }}>
                          <RestartGlyph size={9} />
                          <span style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, fontWeight: 600,
                            letterSpacing: 0.3, textTransform: "uppercase" }}>restart</span>
                        </span>
                      ) : (
                        <span title="Hot-reloadable — applies instantly" style={{
                          display: "inline-flex", alignItems: "center", gap: 3,
                          color: "var(--run-completed)",
                        }}>
                          <HotReloadGlyph size={9} />
                          <span style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, fontWeight: 600,
                            letterSpacing: 0.3, textTransform: "uppercase" }}>hot</span>
                        </span>
                      )}
                    </div>
                  </div>
                  <DotIcon color={a.enabled ? "var(--run-completed)" : "var(--muted-fg)"} size={7} />
                  <AddonToggle on={a.enabled} onClick={(e) => { e.stopPropagation(); toggle(a.id); }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detail reading pane */}
        <div style={{ display: "flex", flexDirection: "column", minHeight: 0,
          background: "var(--app-bg)" }}>
          {/* Subject header */}
          <div style={{
            padding: "14px 20px", borderBottom: "1px solid var(--border)",
            background: "var(--panel-bg)",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{
                width: 42, height: 42, borderRadius: 6,
                background: "var(--node-header-bg)",
                border: "1px solid var(--node-card-border)",
                borderLeft: `4px solid ${catColor(focus.category)}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "var(--node-header-fg)",
              }}>
                <CatIcon cat={focus.category} size={20} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 18, fontWeight: 600, color: "var(--panel-title-fg)" }}>
                    {focus.name}
                  </span>
                  <span style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--muted-fg)" }}>
                    v{focus.version}
                  </span>
                  {focus.version.includes("rc") && (
                    <span style={badgeStyle("warn")}>PRE-RELEASE</span>
                  )}
                  {focus.builtin && <span style={badgeStyle("core")}>BUILT-IN</span>}
                  {focus.restart ? (
                    <span style={{
                      fontSize: 9.5, padding: "1px 6px", borderRadius: 2, fontWeight: 600,
                      letterSpacing: 0.4, background: "rgba(232,168,56,0.14)",
                      color: "var(--edge-warning)", border: "1px solid rgba(232,168,56,0.3)",
                      display: "inline-flex", alignItems: "center", gap: 4,
                    }}>
                      <RestartGlyph size={10} /> REQUIRES RESTART
                    </span>
                  ) : (
                    <span style={{
                      fontSize: 9.5, padding: "1px 6px", borderRadius: 2, fontWeight: 600,
                      letterSpacing: 0.4, background: "rgba(103,212,135,0.14)",
                      color: "var(--run-completed)", border: "1px solid rgba(103,212,135,0.3)",
                      display: "inline-flex", alignItems: "center", gap: 4,
                    }}>
                      <HotReloadGlyph size={10} /> HOT-RELOADABLE
                    </span>
                  )}
                </div>
                <div style={{ fontSize: 11.5, color: "var(--muted-fg)", marginTop: 3 }}>
                  {focus.vendor} · <span style={{ fontFamily: "var(--font-mono)" }}>{focus.id}</span>
                </div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <button style={tbBtn}>Preferences…</button>
                <button style={{
                  ...tbBtn,
                  background: focus.enabled ? "var(--inspector-danger-bg)" : "var(--accent-strong)",
                  borderColor: focus.enabled ? "var(--inspector-danger-border)" : "var(--accent-strong)",
                  color: focus.enabled ? "var(--inspector-danger-fg)" : "#fff",
                }}
                  onClick={() => toggle(focus.id)}>
                  {focus.enabled ? "Disable" : "Enable"}
                </button>
              </div>
            </div>
            {focusPending && (
              <div style={{
                marginTop: 12, padding: "8px 12px",
                background: "rgba(232,168,56,0.10)",
                border: "1px solid rgba(232,168,56,0.35)",
                borderLeft: "3px solid var(--edge-warning)",
                borderRadius: 3, fontSize: 11.5,
                color: "var(--app-fg)", display: "flex", alignItems: "center", gap: 8,
              }}>
                <RestartGlyph size={13} />
                <span>
                  Pending change — this add-on registers native descriptors at startup.
                  Restart the runtime to apply.
                </span>
                <span style={{ flex: 1 }} />
                <button style={{ ...tbBtn, borderColor: "var(--edge-warning)", color: "var(--edge-warning)" }}>
                  Restart now
                </button>
              </div>
            )}
          </div>

          {/* Tabs */}
          <div style={{
            display: "flex", borderBottom: "1px solid var(--border)",
            background: "var(--panel-bg)", padding: "0 14px",
          }}>
            {["about", "dependencies", "nodes", "changelog"].map((t) => (
              <div key={t} onClick={() => setTab(t)}
                style={{
                  padding: "8px 14px", cursor: "default",
                  fontSize: 12, textTransform: "capitalize",
                  color: tab === t ? "var(--panel-title-fg)" : "var(--muted-fg)",
                  borderBottom: tab === t ? "2px solid var(--accent)" : "2px solid transparent",
                  marginBottom: -1, fontWeight: tab === t ? 600 : 400,
                }}>
                {t}
              </div>
            ))}
          </div>

          <div style={{ overflowY: "auto", flex: 1, padding: "20px 24px" }}>
            {tab === "about" && <V4AboutTab focus={focus} dependents={dependents} />}
            {tab === "dependencies" && <V4DepsTab focus={focus} rows={rows} />}
            {tab === "nodes" && <V4NodesTab focus={focus} />}
            {tab === "changelog" && <V4ChangelogTab focus={focus} />}
          </div>
        </div>
      </div>
    </div>
  );
}

function V4AboutTab({ focus, dependents }) {
  return (
    <div style={{ maxWidth: 680 }}>
      <p style={{ fontSize: 13, lineHeight: 1.6, color: "var(--app-fg)", margin: "0 0 16px" }}>
        {focus.long}
      </p>
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12,
        margin: "20px 0",
      }}>
        {[
          ["Category", focus.cat],
          ["Activation", focus.restart ? "Requires restart" : "Hot-reloadable"],
          ["Nodes exposed", focus.nodes],
          ["Last updated", focus.updated],
        ].map(([k, v]) => (
          <div key={k} style={{
            background: "var(--inspector-card-bg)", border: "1px solid var(--border)",
            borderLeft: k === "Activation" ? `3px solid ${focus.restart ? "var(--edge-warning)" : "var(--run-completed)"}` : "1px solid var(--border)",
            borderRadius: 6, padding: "10px 12px",
          }}>
            <div style={{
              fontSize: 9.5, fontWeight: 600, letterSpacing: 0.5,
              color: "var(--muted-fg)", textTransform: "uppercase",
            }}>{k}</div>
            <div style={{
              fontSize: 13, color: "var(--app-fg)", fontFamily: "var(--font-mono)",
              marginTop: 4,
            }}>{v}</div>
          </div>
        ))}
      </div>
      <div className="corex-section-title" style={{
        fontSize: 11, fontWeight: 600, color: "var(--muted-fg)",
        textTransform: "uppercase", letterSpacing: 0.5, margin: "20px 0 8px",
      }}>Python requirement</div>
      <div style={{
        fontFamily: "var(--font-mono)", fontSize: 12, padding: "8px 10px",
        background: "var(--console-bg)", border: "1px solid var(--border)",
        borderRadius: 4, color: "var(--app-fg)",
      }}>
        {focus.requires || "— no pip requirement —"}
      </div>
    </div>
  );
}

function V4DepsTab({ focus, rows }) {
  return (
    <div style={{ maxWidth: 680 }}>
      <div className="corex-section-title" style={{
        fontSize: 11, fontWeight: 600, color: "var(--muted-fg)",
        textTransform: "uppercase", letterSpacing: 0.5, margin: "0 0 10px",
      }}>Python packages required</div>
      {focus.deps.length === 0 ? (
        <div style={{ color: "var(--muted-fg)", fontSize: 12 }}>No external dependencies.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {focus.deps.map(d => (
            <div key={d} style={{
              display: "flex", alignItems: "center", gap: 10,
              background: "var(--inspector-card-bg)", border: "1px solid var(--border)",
              borderRadius: 4, padding: "6px 10px",
            }}>
              <DotIcon color="var(--run-completed)" size={6} />
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{d}</span>
              <span style={{ flex: 1 }} />
              <span style={{ fontSize: 10.5, color: "var(--muted-fg)", fontFamily: "var(--font-mono)" }}>
                satisfied in workspace env
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="corex-section-title" style={{
        fontSize: 11, fontWeight: 600, color: "var(--muted-fg)",
        textTransform: "uppercase", letterSpacing: 0.5, margin: "20px 0 10px",
      }}>Other add-ons that depend on this</div>
      <div style={{ color: "var(--muted-fg)", fontSize: 12 }}>
        No add-ons currently depend on <span style={{ fontFamily: "var(--font-mono)" }}>{focus.id}</span>.
      </div>
    </div>
  );
}

function V4NodesTab({ focus }) {
  const mockNodes = [
    ["Read Result File", "core", "input"],
    ["Stress (Component)", "physics", "compute"],
    ["Displacement", "physics", "compute"],
    ["Fatigue — Rainflow", "physics", "compute"],
    ["Mesh Viewer", "default", "viewer"],
    ["Export CSV", "io", "output"],
  ];
  return (
    <div style={{ maxWidth: 680 }}>
      <div style={{ color: "var(--muted-fg)", fontSize: 11.5, marginBottom: 10 }}>
        Showing 6 of {focus.nodes} descriptors registered by this add-on.
      </div>
      <div style={{
        border: "1px solid var(--border)", borderRadius: 6,
        overflow: "hidden",
      }}>
        {mockNodes.map((n, i) => (
          <div key={n[0]} style={{
            display: "grid", gridTemplateColumns: "28px 1fr 100px 80px",
            alignItems: "center", gap: 10, padding: "8px 12px",
            background: i % 2 ? "var(--panel-bg)" : "var(--panel-alt-bg)",
            borderBottom: i < 5 ? "1px solid var(--border)" : "none",
          }}>
            <div style={{ color: "var(--muted-fg)" }}><CatIcon cat={n[1]} size={13} /></div>
            <span style={{ fontSize: 12 }}>{n[0]}</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--muted-fg)" }}>
              {n[2]}
            </span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--muted-fg)" }}>
              {focus.id.split("-")[0]}.{n[0].toLowerCase().replace(/[^a-z]+/g, "_")}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function V4ChangelogTab({ focus }) {
  const entries = [
    [focus.version, focus.updated, ["Descriptor-first registration stabilized.", "Added invariant-kernel guarantees for compute nodes.", "Fix: passive flow edges propagate scope correctly."]],
    ["1.3.7", "2026-02-18", ["Quick-insert overlay integration.", "Minor perf work on graph-hash caching."]],
    ["1.3.0", "2025-12-04", ["Initial public release into the COREX registry."]],
  ];
  return (
    <div style={{ maxWidth: 680 }}>
      {entries.map(([v, d, list]) => (
        <div key={v} style={{ marginBottom: 22 }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 6 }}>
            <span style={{
              fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--accent)",
              fontWeight: 600,
            }}>v{v}</span>
            <span style={{ fontSize: 11, color: "var(--muted-fg)" }}>{d}</span>
          </div>
          <ul style={{ margin: 0, paddingLeft: 16, color: "var(--app-fg)", fontSize: 12, lineHeight: 1.6 }}>
            {list.map((x, i) => <li key={i}>{x}</li>)}
          </ul>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { V4_InspectorDrawer });

function RestartGlyph({ size = 11 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 4v6h6" />
      <path d="M20 20v-6h-6" />
      <path d="M20 9a8 8 0 0 0-14.3-2.7L4 10" />
      <path d="M4 15a8 8 0 0 0 14.3 2.7L20 14" />
    </svg>
  );
}
function HotReloadGlyph({ size = 11 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M13 3l-8 12h6l-1 6 8-12h-6z" fill="currentColor" />
    </svg>
  );
}
Object.assign(window, { RestartGlyph, HotReloadGlyph });