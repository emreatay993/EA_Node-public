// Variant 2 — "Marketplace Grid" — card grid with filter rail.
// Feels like a VSCode/JetBrains extensions surface. Each card shows category icon,
// name, vendor, short summary, version, node count, and an enable toggle.

function V2_MarketplaceGrid() {
  const [q, setQ] = React.useState("");
  const [filter, setFilter] = React.useState("installed"); // installed | enabled | disabled | updates | all
  const [rows, setRows] = React.useState(ADDONS);
  const toggle = (id) => setRows(rs => rs.map(r => r.id === id
    ? { ...r, enabled: !r.enabled, status: !r.enabled ? "loaded" : "disabled" } : r));

  const matches = rows.filter(r => {
    if (filter === "enabled" && !r.enabled) return false;
    if (filter === "disabled" && r.enabled) return false;
    if (filter === "updates" && !r.version.includes("rc")) return false;
    if (q && !r.name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  const sortOrder = [...matches].sort((a, b) => {
    // pinned & built-in first, then enabled, then name
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    if (a.builtin !== b.builtin) return a.builtin ? -1 : 1;
    if (a.enabled !== b.enabled) return a.enabled ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  return (
    <div data-theme="stitch-dark" style={{
      width: 1180, height: 760, background: "var(--app-bg)", color: "var(--app-fg)",
      fontFamily: "var(--font-ui)", fontSize: 12, display: "flex", flexDirection: "column",
      border: "1px solid var(--border)",
    }}>
      {/* Header */}
      <div style={{
        background: "var(--toolbar-bg)", borderBottom: "1px solid var(--border)",
        padding: "10px 14px", display: "flex", alignItems: "center", gap: 12,
      }}>
        <img src="assets/corex_app.svg" style={{ width: 16, height: 16 }} />
        <span style={{ fontWeight: 600, fontSize: 13, color: "var(--panel-title-fg)", letterSpacing: 0.3 }}>
          Add-ons
        </span>
        <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>
          Extend the runtime with node packages, integrations, and viewers.
        </span>
        <span style={{ flex: 1 }} />
        <div style={{ position: "relative", width: 300 }}>
          <span style={{ position: "absolute", left: 8, top: 6, color: "var(--muted-fg)" }}>
            <SearchIcon size={13} />
          </span>
          <input value={q} onChange={e => setQ(e.target.value)}
            placeholder="Search installed add-ons…"
            style={{
              width: "100%", background: "var(--input-bg)", border: "1px solid var(--input-border)",
              color: "var(--input-fg)", padding: "4px 8px 4px 26px", borderRadius: 3, fontSize: 12,
            }} />
        </div>
      </div>

      {/* Filter rail + grid */}
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "200px 1fr", minHeight: 0 }}>
        {/* Left rail */}
        <div style={{
          borderRight: "1px solid var(--border)", background: "var(--panel-bg)",
          padding: "12px 8px", display: "flex", flexDirection: "column", gap: 2,
        }}>
          <div style={{
            fontSize: 11, color: "var(--muted-fg)", fontWeight: 600,
            textTransform: "uppercase", letterSpacing: 0.5, padding: "4px 8px 8px",
          }}>Library</div>
          {[
            ["installed", "Installed", rows.length],
            ["enabled", "Enabled", rows.filter(r => r.enabled).length],
            ["disabled", "Disabled", rows.filter(r => !r.enabled).length],
            ["updates", "Updates", rows.filter(r => r.version.includes("rc")).length],
          ].map(([k, label, n]) => (
            <div key={k} onClick={() => setFilter(k)}
              style={{
                display: "flex", alignItems: "center", gap: 6, padding: "5px 8px",
                cursor: "default", fontSize: 12,
                background: filter === k ? "var(--inspector-selected-bg)" : "transparent",
                color: filter === k ? "var(--app-fg)" : "var(--muted-fg)",
                borderRadius: 3,
              }}>
              <span style={{ flex: 1 }}>{label}</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5 }}>{n}</span>
            </div>
          ))}

          <div style={{
            fontSize: 11, color: "var(--muted-fg)", fontWeight: 600,
            textTransform: "uppercase", letterSpacing: 0.5, padding: "16px 8px 8px",
          }}>Categories</div>
          {["Ansys DPF", "HPC", "Physics", "Logic", "Integrations", "Core", "Passive / Visual", "CAD"].map(c => {
            const n = rows.filter(r => r.cat === c).length;
            return (
              <div key={c} style={{
                display: "flex", alignItems: "center", gap: 6, padding: "4px 8px",
                fontSize: 12, color: "var(--muted-fg)",
              }}>
                <span style={{ flex: 1 }}>{c}</span>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5 }}>{n}</span>
              </div>
            );
          })}

          <div style={{ flex: 1 }} />
          <button style={{
            ...tbBtn, justifyContent: "center", marginTop: 8,
          }}>+ Install from File…</button>
        </div>

        {/* Grid of cards */}
        <div style={{
          overflowY: "auto", padding: 18,
          background: "var(--app-bg)",
        }}>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
            gap: 12,
          }}>
            {sortOrder.map(a => <MarketCard key={a.id} a={a} onToggle={() => toggle(a.id)} />)}
          </div>
        </div>
      </div>

      {/* Footer (status bar feel) */}
      <div style={{
        background: "var(--status-bg)", color: "var(--status-fg)",
        padding: "4px 12px", fontSize: 11,
        display: "flex", alignItems: "center", gap: 12,
      }}>
        <span>COREX 2026.2.0</span>
        <span style={{ opacity: 0.5 }}>|</span>
        <span>{rows.filter(r => r.enabled).length} add-ons loaded · {rows.reduce((s, r) => s + (r.enabled ? r.nodes : 0), 0)} nodes registered</span>
        <span style={{ flex: 1 }} />
        <span>Runtime: idle</span>
      </div>
    </div>
  );
}

function MarketCard({ a, onToggle }) {
  return (
    <div style={{
      background: "var(--node-card-bg)", border: "1px solid var(--node-card-border)",
      borderRadius: 8, padding: 0, overflow: "hidden",
      display: "flex", flexDirection: "column",
      opacity: a.enabled ? 1 : 0.82,
    }}>
      {/* header strip */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "8px 10px", background: "var(--node-header-bg)",
        borderBottom: "1px solid var(--node-card-border)",
        borderLeft: `3px solid ${catColor(a.category)}`,
      }}>
        <div style={{
          width: 24, height: 24, borderRadius: 3,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "var(--node-header-fg)", background: "rgba(255,255,255,0.04)",
        }}>
          <CatIcon cat={a.category} size={14} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{
            fontWeight: 600, fontSize: 12.5, color: "var(--node-header-fg)",
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
          }}>{a.name}</div>
          <div style={{
            fontSize: 10.5, color: "var(--muted-fg)",
            fontFamily: "var(--font-mono)",
          }}>
            {a.vendor} · v{a.version}
          </div>
        </div>
        <div style={{
          fontSize: 10, padding: "1px 6px", borderRadius: 999,
          color: a.enabled ? "var(--run-completed)" : "var(--muted-fg)",
          background: a.enabled ? "rgba(103,212,135,0.12)" : "var(--panel-alt-bg)",
          border: `1px solid ${a.enabled ? "rgba(103,212,135,0.3)" : "var(--border)"}`,
          fontWeight: 600, letterSpacing: 0.3,
        }}>
          {a.enabled ? "LOADED" : "DISABLED"}
        </div>
      </div>

      {/* body */}
      <div style={{
        padding: "10px 12px", fontSize: 11.5, lineHeight: 1.5,
        color: "var(--app-fg)", flex: 1, minHeight: 56,
      }}>
        {a.summary}
      </div>

      {/* meta row */}
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
        padding: "8px 12px", gap: 8,
        background: "var(--node-inline-row-bg)",
        borderTop: "1px solid var(--node-card-border)",
        borderBottom: "1px solid var(--node-card-border)",
      }}>
        {[
          ["NODES", a.nodes],
          ["SIZE", a.size],
          ["CATEGORY", a.cat],
        ].map(([k, v]) => (
          <div key={k}>
            <div style={{
              fontSize: 9, color: "var(--muted-fg)", fontWeight: 600,
              letterSpacing: 0.5, textTransform: "uppercase",
            }}>{k}</div>
            <div style={{
              fontSize: 11, color: "var(--app-fg)", fontFamily: "var(--font-mono)",
              marginTop: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
            }}>{v}</div>
          </div>
        ))}
      </div>

      {/* footer action */}
      <div style={{
        padding: "8px 10px", display: "flex", alignItems: "center", gap: 6,
      }}>
        <button style={{ ...tbBtn, fontSize: 11, padding: "2px 8px" }}>Details</button>
        <span style={{ flex: 1 }} />
        <span style={{ fontSize: 10.5, color: "var(--muted-fg)" }}>
          {a.enabled ? "Enabled" : "Disabled"}
        </span>
        <AddonToggle on={a.enabled} onClick={onToggle} />
      </div>
    </div>
  );
}

Object.assign(window, { V2_MarketplaceGrid, MarketCard });
