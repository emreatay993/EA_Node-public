// Variant 5 — "Dependency Graph"
// Add-ons visualized as COREX nodes on a canvas. Dependency edges flow
// left→right in layered lanes (like a real pipeline). Unique to this product:
// the add-on manager IS a graph, because the product is a graph editor.

function V5_DependencyGraph() {
  const [rows, setRows] = React.useState(ADDONS);
  const [sel, setSel] = React.useState("hpc-slurm");
  const [showDisabled, setShowDisabled] = React.useState(true);
  const toggle = (id) => setRows(rs => rs.map(r => r.id === id
    ? { ...r, enabled: !r.enabled, status: !r.enabled ? "loaded" : "disabled" } : r));
  const focus = rows.find(r => r.id === sel);

  // Layered layout: columns = logical layers (foundations → integrations → consumers)
  // Canvas is ~820w × 620h inside the left pane.
  const NODE_W = 210, NODE_H = 84, COL_W = 270;
  const LAYER = {
    foundations: { x: 40,  label: "Foundations" },
    runtime:     { x: 40 + COL_W,     label: "Runtime services" },
    consumers:   { x: 40 + 2 * COL_W, label: "Consumers" },
  };
  const layout = {
    // foundations
    "ansys-dpf-core":   { col: "foundations", row: 0 },
    "signal-proc":      { col: "foundations", row: 1 },
    "git-sync":         { col: "foundations", row: 2 },
    "annot-cards":      { col: "foundations", row: 3 },
    // runtime services
    "hpc-slurm":        { col: "runtime",     row: 0 },
    "excel-bridge":     { col: "runtime",     row: 1 },
    "email-int":        { col: "runtime",     row: 2 },
    "matlab-int":       { col: "runtime",     row: 3 },
    // consumers
    "optimize":         { col: "consumers",   row: 0 },
    "parasolid-reader": { col: "consumers",   row: 1 },
    "video-export":     { col: "consumers",   row: 2 },
    "pdf-panels":       { col: "consumers",   row: 3 },
  };
  const ROW_GAP = 32;
  const ROW_Y0 = 104;
  const pos = (id) => {
    const L = layout[id]; if (!L) return null;
    return { x: LAYER[L.col].x, y: ROW_Y0 + L.row * (NODE_H + ROW_GAP) };
  };

  // Dependency edges (mock)
  const edges = [
    ["hpc-slurm",        "ansys-dpf-core"],
    ["optimize",         "signal-proc"],
    ["optimize",         "hpc-slurm"],
    ["video-export",     "pdf-panels"],
    ["video-export",     "ansys-dpf-core"],
    ["parasolid-reader", "excel-bridge"],
    ["matlab-int",       "signal-proc"],
    ["pdf-panels",       "annot-cards"],
  ];
  const stats = {
    loaded: rows.filter(r => r.enabled).length,
    disabled: rows.filter(r => !r.enabled).length,
    nodes: rows.reduce((s, r) => s + (r.enabled ? r.nodes : 0), 0),
  };
  // dependents/dependencies of the focused
  const focusDeps = edges.filter(([f]) => f === sel).map(([, t]) => t);
  const focusDependents = edges.filter(([, t]) => t === sel).map(([f]) => f);
  const relatedSet = new Set([sel, ...focusDeps, ...focusDependents]);

  return (
    <div data-theme="stitch-dark" style={{
      width: 1180, height: 760, background: "var(--app-bg)", color: "var(--app-fg)",
      fontFamily: "var(--font-ui)", fontSize: 12, display: "flex", flexDirection: "column",
      border: "1px solid var(--border)",
    }}>
      {/* Toolbar */}
      <div style={{
        background: "var(--toolbar-bg)", borderBottom: "1px solid var(--border)",
        padding: "6px 10px", display: "flex", alignItems: "center", gap: 6,
      }}>
        <img src="assets/corex_app.svg" style={{ width: 14, height: 14 }} />
        <span style={{ fontWeight: 600, fontSize: 13, color: "var(--panel-title-fg)" }}>
          Add-on Graph
        </span>
        <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>
          · load order flows left → right · click a node to inspect · double-click to toggle
        </span>
        <span style={{ flex: 1 }} />
        <button style={{ ...tbBtn, borderColor: showDisabled ? "var(--border)" : "var(--accent)",
          color: showDisabled ? "var(--app-fg)" : "var(--accent)" }}
          onClick={() => setShowDisabled(s => !s)}>
          {showDisabled ? "Hide disabled" : "Show disabled"}
        </button>
        <button style={tbBtn}>Auto-layout</button>
        <button style={tbBtn}>Fit</button>
        <div style={{ width: 1, height: 16, background: "var(--border)", margin: "0 4px" }} />
        <button style={tbBtn}>Install from File…</button>
        <button style={{ ...tbBtn, background: "var(--accent-strong)", color: "#fff", borderColor: "var(--accent-strong)" }}>
          Apply & Reload
        </button>
      </div>

      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 320px", minHeight: 0 }}>
        {/* Canvas pane */}
        <div style={{
          position: "relative", overflow: "hidden",
          background: "var(--canvas-bg)",
          backgroundImage: `
            linear-gradient(var(--canvas-minor-grid) 1px, transparent 1px),
            linear-gradient(90deg, var(--canvas-minor-grid) 1px, transparent 1px),
            linear-gradient(var(--canvas-major-grid) 1px, transparent 1px),
            linear-gradient(90deg, var(--canvas-major-grid) 1px, transparent 1px)
          `,
          backgroundSize: "16px 16px, 16px 16px, 96px 96px, 96px 96px",
        }}>
          {/* Stats HUD */}
          <div style={{
            position: "absolute", top: 12, left: 14, zIndex: 3,
            background: "rgba(0,0,0,0.35)", padding: "6px 10px", borderRadius: 4,
            border: "1px solid var(--border)",
            display: "flex", alignItems: "center", gap: 12, fontSize: 11,
          }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
              <DotIcon color="var(--run-completed)" /> {stats.loaded} loaded
            </span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
              <DotIcon color="var(--muted-fg)" /> {stats.disabled} disabled
            </span>
            <span style={{ opacity: 0.4 }}>·</span>
            <span style={{ fontFamily: "var(--font-mono)" }}>{stats.nodes} nodes registered</span>
          </div>

          {/* Layer titles — pinned above the first row */}
          <div style={{ position: "absolute", top: 60, left: 0, right: 0, height: 24, pointerEvents: "none", zIndex: 2 }}>
            {Object.entries(LAYER).map(([k, L]) => (
              <div key={k} style={{
                position: "absolute", left: L.x, width: NODE_W,
                fontSize: 10,
                color: "var(--muted-fg)", fontWeight: 600,
                textTransform: "uppercase", letterSpacing: 0.8,
              }}>
                <span style={{
                  padding: "2px 8px", background: "rgba(0,0,0,0.5)",
                  border: "1px solid var(--border)", borderRadius: 2,
                }}>{L.label}</span>
              </div>
            ))}
          </div>

          {/* Vertical lane guides */}
          <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
            {Object.values(LAYER).map((L, i) => (
              <line key={i} x1={L.x + NODE_W + 30} y1={70} x2={L.x + NODE_W + 30} y2={560}
                stroke="var(--border)" strokeDasharray="2 4" opacity={0.5} />
            ))}

            {/* Edges */}
            <defs>
              <marker id="arr-active" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M0,0 L10,5 L0,10 z" fill="var(--accent)" />
              </marker>
              <marker id="arr-dim" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
                <path d="M0,0 L10,5 L0,10 z" fill="var(--border)" />
              </marker>
              <marker id="arr-focus" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                <path d="M0,0 L10,5 L0,10 z" fill="var(--edge-warning)" />
              </marker>
            </defs>

            {edges.map(([from, to], i) => {
              const a = pos(from), b = pos(to); if (!a || !b) return null;
              const src = rows.find(r => r.id === from);
              const dst = rows.find(r => r.id === to);
              if (!showDisabled && (!src.enabled || !dst.enabled)) return null;
              const active = src?.enabled && dst?.enabled;
              const involved = sel === from || sel === to;
              // from is a consumer (right), to is a dep (left). Draw arrow from dep->consumer.
              const x1 = b.x + NODE_W, y1 = b.y + NODE_H / 2;
              const x2 = a.x,          y2 = a.y + NODE_H / 2;
              const mid = (x1 + x2) / 2;
              const d = `M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`;
              const stroke = involved ? "var(--edge-warning)" : (active ? "var(--accent)" : "var(--border)");
              const marker = involved ? "url(#arr-focus)" : (active ? "url(#arr-active)" : "url(#arr-dim)");
              return (
                <path key={i} d={d}
                  stroke={stroke}
                  strokeWidth={involved ? 2 : (active ? 1.5 : 1)}
                  strokeDasharray={active ? "none" : "4 3"}
                  fill="none"
                  opacity={involved ? 1 : (active ? 0.85 : 0.5)}
                  markerEnd={marker}
                />
              );
            })}
          </svg>

          {/* Nodes */}
          {rows.map(a => {
            const p = pos(a.id); if (!p) return null;
            if (!showDisabled && !a.enabled) return null;
            const isSel = sel === a.id;
            const isDim = sel && !relatedSet.has(a.id);
            return (
              <div key={a.id}
                onClick={() => setSel(a.id)}
                onDoubleClick={() => toggle(a.id)}
                style={{
                  position: "absolute", top: p.y, left: p.x,
                  width: NODE_W, background: "var(--node-card-bg)",
                  border: isSel ? "2px solid var(--node-card-selected-border)" : "1px solid var(--node-card-border)",
                  borderRadius: 8, boxShadow: "var(--shadow-node)",
                  opacity: !a.enabled ? 0.5 : (isDim ? 0.55 : 1),
                  filter: isDim ? "saturate(0.6)" : "none",
                  cursor: "pointer", transition: "opacity 100ms",
                  zIndex: isSel ? 2 : 1,
                }}>
                {/* header */}
                <div style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "6px 10px", background: "var(--node-header-bg)",
                  borderBottom: "1px solid var(--node-card-border)",
                  borderLeft: `3px solid ${catColor(a.category)}`,
                  borderTopLeftRadius: isSel ? 6 : 7,
                  borderTopRightRadius: isSel ? 6 : 7,
                }}>
                  <div style={{ color: "var(--node-header-fg)" }}>
                    <CatIcon cat={a.category} size={12} />
                  </div>
                  <div style={{
                    flex: 1, minWidth: 0,
                    fontSize: 12, fontWeight: 600, color: "var(--node-header-fg)",
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  }}>{a.name}</div>
                  <div style={{
                    fontSize: 9, padding: "0px 5px", borderRadius: 2, fontWeight: 600,
                    letterSpacing: 0.4,
                    color: a.enabled ? "var(--run-completed)" : "var(--muted-fg)",
                    background: a.enabled ? "rgba(103,212,135,0.12)" : "var(--panel-alt-bg)",
                    border: `1px solid ${a.enabled ? "rgba(103,212,135,0.3)" : "var(--border)"}`,
                  }}>{a.enabled ? "ON" : "OFF"}</div>
                </div>
                {/* body */}
                <div style={{ padding: "6px 8px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                  <div style={{
                    padding: "3px 6px", background: "var(--node-inline-row-bg)",
                    border: "1px solid var(--node-inline-row-border)", borderRadius: 3,
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                  }}>
                    <span style={{ fontSize: 10, color: "var(--muted-fg)" }}>v</span>
                    <span style={{ fontSize: 10, color: "var(--input-fg)", fontFamily: "var(--font-mono)" }}>
                      {a.version}
                    </span>
                  </div>
                  <div style={{
                    padding: "3px 6px", background: "var(--node-inline-row-bg)",
                    border: "1px solid var(--node-inline-row-border)", borderRadius: 3,
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                  }}>
                    <span style={{ fontSize: 10, color: "var(--muted-fg)" }}>nodes</span>
                    <span style={{ fontSize: 10, color: "var(--input-fg)", fontFamily: "var(--font-mono)" }}>
                      {a.nodes}
                    </span>
                  </div>
                </div>
                {/* ports (only ones that are actually connected) */}
                {edges.some(([f, t]) => t === a.id) && (
                  <div style={{
                    position: "absolute", right: -5, top: 28,
                    width: 10, height: 10, borderRadius: "50%",
                    background: "var(--node-port-fill)", border: "2px solid var(--node-port-border)",
                    boxShadow: "0 0 0 3px var(--node-port-ring-fill)",
                  }} />
                )}
                {edges.some(([f]) => f === a.id) && (
                  <div style={{
                    position: "absolute", left: -5, top: 28,
                    width: 10, height: 10, borderRadius: "50%",
                    background: "var(--node-port-fill)", border: "2px solid var(--node-port-border)",
                    boxShadow: "0 0 0 3px var(--node-port-ring-fill)",
                  }} />
                )}
              </div>
            );
          })}

          {/* Legend */}
          <div style={{
            position: "absolute", bottom: 12, left: 14, zIndex: 3,
            background: "rgba(0,0,0,0.35)", padding: "6px 10px", borderRadius: 4,
            border: "1px solid var(--border)", fontSize: 10.5,
            display: "flex", alignItems: "center", gap: 14,
          }}>
            <LegendSwatch color="var(--accent)" label="active dependency" />
            <LegendSwatch color="var(--border)" dashed label="inactive (upstream off)" />
            <LegendSwatch color="var(--edge-warning)" label="touches selection" />
          </div>

          {/* Minimap */}
          <div style={{
            position: "absolute", bottom: 10, right: 10, zIndex: 3,
            width: 180, height: 100, background: "rgba(0,0,0,0.55)",
            border: "1px solid var(--border)", borderRadius: 4,
            padding: 4,
          }}>
            {rows.map(a => {
              const p = pos(a.id); if (!p) return null;
              return (
                <div key={a.id} style={{
                  position: "absolute",
                  left: 4 + (p.x / 860) * 172,
                  top:  4 + (p.y / 540) * 92,
                  width: 16, height: 6,
                  background: a.enabled ? "var(--node-header-bg)" : "var(--panel-alt-bg)",
                  border: `1px solid ${sel === a.id ? "var(--accent)" : catColor(a.category)}`,
                  borderRadius: 1,
                  opacity: a.enabled ? 1 : 0.45,
                }} />
              );
            })}
            <div style={{
              position: "absolute", top: 2, left: 6,
              fontSize: 9, color: "var(--muted-fg)", letterSpacing: 0.5,
              textTransform: "uppercase", fontWeight: 600,
            }}>Overview</div>
          </div>
        </div>

        {/* Inspector */}
        <div style={{
          background: "var(--panel-bg)", borderLeft: "1px solid var(--border)",
          display: "flex", flexDirection: "column", minWidth: 0,
        }}>
          <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--border)",
            display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 4,
              background: "var(--node-header-bg)",
              border: "1px solid var(--node-card-border)",
              borderLeft: `3px solid ${catColor(focus.category)}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "var(--node-header-fg)",
            }}>
              <CatIcon cat={focus.category} size={15} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--panel-title-fg)",
                whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {focus.name}
              </div>
              <div style={{ fontSize: 10.5, color: "var(--muted-fg)",
                fontFamily: "var(--font-mono)", marginTop: 1 }}>
                {focus.id}
              </div>
            </div>
            <AddonToggle on={focus.enabled} onClick={() => toggle(focus.id)} />
          </div>

          <div style={sectTitle}>Properties</div>
          <div style={rowsGrid}>
            <span style={l}>Vendor</span><span style={v}>{focus.vendor}</span>
            <span style={l}>Version</span><span style={v}>{focus.version}</span>
            <span style={l}>Category</span><span style={v}>{focus.cat}</span>
            <span style={l}>Install size</span><span style={v}>{focus.size}</span>
            <span style={l}>Nodes</span><span style={v}>{focus.nodes}</span>
            <span style={l}>Updated</span><span style={v}>{focus.updated}</span>
          </div>

          <div style={sectTitle}>Requires ({focusDeps.length})</div>
          <div style={{ padding: "6px 12px" }}>
            {focusDeps.length === 0 ? (
              <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>— none —</span>
            ) : focusDeps.map(d => {
              const r = rows.find(x => x.id === d);
              return (
                <div key={d} onClick={() => setSel(d)} style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "3px 6px", fontSize: 11.5, cursor: "default",
                  borderRadius: 3,
                }}>
                  <span style={{
                    width: 8, height: 8, borderRadius: 2,
                    background: catColor(r.category), flexShrink: 0,
                  }} />
                  <span style={{ flex: 1, color: "var(--app-fg)" }}>{r.name}</span>
                  <DotIcon color={r.enabled ? "var(--run-completed)" : "var(--muted-fg)"} size={6} />
                </div>
              );
            })}
          </div>

          <div style={sectTitle}>Required by ({focusDependents.length})</div>
          <div style={{ padding: "6px 12px" }}>
            {focusDependents.length === 0 ? (
              <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>— none —</span>
            ) : focusDependents.map(d => {
              const r = rows.find(x => x.id === d);
              return (
                <div key={d} onClick={() => setSel(d)} style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "3px 6px", fontSize: 11.5, cursor: "default",
                  borderRadius: 3,
                }}>
                  <span style={{
                    width: 8, height: 8, borderRadius: 2,
                    background: catColor(r.category), flexShrink: 0,
                  }} />
                  <span style={{ flex: 1, color: "var(--app-fg)" }}>{r.name}</span>
                  <DotIcon color={r.enabled ? "var(--run-completed)" : "var(--muted-fg)"} size={6} />
                </div>
              );
            })}
          </div>

          <div style={sectTitle}>Description</div>
          <div style={{
            padding: "8px 12px", fontSize: 11.5, lineHeight: 1.5,
            color: "var(--app-fg)", flex: 1, overflowY: "auto",
          }}>
            {focus.long}
          </div>

          <div style={{
            borderTop: "1px solid var(--border)", padding: "8px 12px",
            display: "flex", gap: 6, background: "var(--toolbar-bg)",
          }}>
            <button style={{ ...tbBtn, flex: 1 }}>Isolate subgraph</button>
            <button style={{
              ...tbBtn, flex: 1,
              background: focus.enabled ? "var(--inspector-danger-bg)" : "var(--accent-strong)",
              color: focus.enabled ? "var(--inspector-danger-fg)" : "#fff",
              borderColor: focus.enabled ? "var(--inspector-danger-border)" : "var(--accent-strong)",
            }} onClick={() => toggle(focus.id)}>
              {focus.enabled ? "Disable" : "Enable"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function LegendSwatch({ color, label, dashed }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted-fg)" }}>
      <svg width="24" height="8" style={{ overflow: "visible" }}>
        <line x1="0" y1="4" x2="22" y2="4" stroke={color} strokeWidth="2"
          strokeDasharray={dashed ? "3 3" : "none"} />
      </svg>
      {label}
    </span>
  );
}

Object.assign(window, { V5_DependencyGraph, LegendSwatch });
