// Variant 1 — "Settings Dialog" — native COREX Qt-style modal.
// Left categories tree + right list of add-on rows with inline toggle, version, size.
// This is the closest to what a native `Manage Add-ons…` dialog would look like today.

function AddonToggle({ on, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        width: 30, height: 16, padding: 0, border: "1px solid",
        borderColor: on ? "var(--accent)" : "var(--input-border)",
        background: on ? "rgba(96,205,255,0.22)" : "var(--input-bg)",
        borderRadius: 999, position: "relative", cursor: "pointer",
        transition: "background 80ms",
      }}
      aria-pressed={on}
    >
      <span style={{
        position: "absolute", top: 1, left: on ? 15 : 1,
        width: 12, height: 12, borderRadius: "50%",
        background: on ? "var(--accent)" : "var(--muted-fg)",
        transition: "left 100ms",
      }} />
    </button>
  );
}

function V1_SettingsDialog() {
  const [sel, setSel] = React.useState("All");
  const [q, setQ] = React.useState("");
  const [rows, setRows] = React.useState(ADDONS);
  const cats = ["All", "Enabled", "Disabled", "Built-in",
    ...Array.from(new Set(ADDONS.map(a => a.cat)))];
  const count = {
    All: rows.length,
    Enabled: rows.filter(r => r.enabled).length,
    Disabled: rows.filter(r => !r.enabled).length,
    "Built-in": rows.filter(r => r.builtin).length,
  };

  const visible = rows.filter(r => {
    if (sel === "Enabled" && !r.enabled) return false;
    if (sel === "Disabled" && r.enabled) return false;
    if (sel === "Built-in" && !r.builtin) return false;
    if (!["All", "Enabled", "Disabled", "Built-in"].includes(sel) && r.cat !== sel) return false;
    if (q && !r.name.toLowerCase().includes(q.toLowerCase()) && !r.id.includes(q.toLowerCase())) return false;
    return true;
  });

  const toggle = (id) => setRows(rs => rs.map(r => r.id === id ? { ...r, enabled: !r.enabled, status: !r.enabled ? "loaded" : "disabled" } : r));
  const [focusId, setFocusId] = React.useState("hpc-slurm");
  const focus = rows.find(r => r.id === focusId);

  return (
    <div data-theme="stitch-dark" style={{
      width: 1180, height: 760, background: "var(--app-bg)", color: "var(--app-fg)",
      fontFamily: "var(--font-ui)", fontSize: 12, display: "flex", flexDirection: "column",
      border: "1px solid var(--border)", boxShadow: "var(--shadow-popup)",
    }}>
      {/* Title bar */}
      <div style={{
        background: "var(--toolbar-bg)", borderBottom: "1px solid var(--border)",
        padding: "8px 12px", display: "flex", alignItems: "center", gap: 10,
      }}>
        <img src="assets/corex_app.svg" style={{ width: 14, height: 14 }} />
        <span style={{ fontWeight: 600, fontSize: 13, color: "var(--panel-title-fg)", letterSpacing: 0.3 }}>
          Add-on Manager
        </span>
        <span style={{ color: "var(--muted-fg)", fontSize: 11, fontFamily: "var(--font-mono)" }}>
          — COREX Node Editor 2026.2.0
        </span>
        <span style={{ flex: 1 }} />
        <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>{count.Enabled} of {count.All} enabled</span>
        <div style={{ width: 1, height: 16, background: "var(--border)", margin: "0 6px" }} />
        <button className="tb" style={tbBtn}>Refresh Registry</button>
        <button className="tb" style={tbBtn}>Install from File…</button>
      </div>

      {/* Body: category tree | list | detail */}
      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "220px 1fr 340px", minHeight: 0 }}>
        {/* Categories tree */}
        <div style={{ borderRight: "1px solid var(--border)", background: "var(--panel-bg)",
          display: "flex", flexDirection: "column" }}>
          <div style={{
            background: "var(--toolbar-bg)", padding: "5px 10px", borderBottom: "1px solid var(--border)",
            fontWeight: 700, fontSize: 13, color: "var(--panel-title-fg)", letterSpacing: 0.4,
          }}>
            Categories
          </div>
          <div style={{ overflowY: "auto", flex: 1, padding: "4px 0" }}>
            {cats.map(c => {
              const ct = count[c] !== undefined ? count[c] : rows.filter(r => r.cat === c).length;
              const isStatus = ["All", "Enabled", "Disabled", "Built-in"].includes(c);
              return (
                <div key={c}
                  onClick={() => setSel(c)}
                  style={{
                    display: "flex", alignItems: "center", gap: 6,
                    padding: "4px 10px", cursor: "default",
                    background: sel === c ? "var(--inspector-selected-bg)" : "transparent",
                    color: sel === c ? "var(--app-fg)" : (isStatus ? "var(--app-fg)" : "var(--group-title-fg)"),
                    fontWeight: isStatus ? 600 : 400, fontSize: 12,
                    borderLeft: sel === c ? "2px solid var(--accent)" : "2px solid transparent",
                  }}>
                  <span style={{ flex: 1 }}>{c}</span>
                  <span style={{
                    color: "var(--muted-fg)", fontSize: 10.5,
                    fontFamily: "var(--font-mono)",
                  }}>{ct}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Middle: search + list of rows */}
        <div style={{ display: "flex", flexDirection: "column", minWidth: 0, background: "var(--panel-bg)" }}>
          <div style={{
            padding: "6px 10px", borderBottom: "1px solid var(--border)",
            display: "flex", gap: 6, alignItems: "center",
          }}>
            <div style={{ position: "relative", flex: 1 }}>
              <span style={{ position: "absolute", left: 8, top: 5, color: "var(--muted-fg)" }}>
                <SearchIcon size={13} />
              </span>
              <input
                value={q} onChange={e => setQ(e.target.value)}
                placeholder="Search add-ons by name or id…"
                style={{
                  width: "100%", background: "var(--input-bg)", border: "1px solid var(--input-border)",
                  color: "var(--input-fg)", padding: "3px 8px 3px 26px", borderRadius: 3, fontSize: 12,
                }}
              />
            </div>
            <button style={tbBtn}><Chev dir="down" /> Sort: Name</button>
          </div>

          <div style={{ overflowY: "auto", flex: 1 }}>
            {visible.map(a => (
              <div key={a.id}
                onClick={() => setFocusId(a.id)}
                style={{
                  display: "grid",
                  gridTemplateColumns: "36px 1fr auto auto auto auto",
                  alignItems: "center", gap: 10, padding: "8px 12px",
                  borderBottom: "1px solid var(--border)",
                  background: focusId === a.id ? "var(--inspector-selected-bg)" : "transparent",
                  cursor: "default",
                }}>
                {/* Accent stripe + icon */}
                <div style={{
                  width: 28, height: 28, borderRadius: 4,
                  background: "var(--node-header-bg)",
                  border: "1px solid var(--node-card-border)",
                  borderLeft: `3px solid ${catColor(a.category)}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "var(--node-header-fg)",
                }}>
                  <CatIcon cat={a.category} size={14} />
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ fontWeight: 600, fontSize: 12.5, color: "var(--panel-title-fg)" }}>
                      {a.name}
                    </span>
                    {a.builtin && <span style={badgeStyle("core")}>BUILT-IN</span>}
                    {a.pinned && <span style={badgeStyle("accent")}>PINNED</span>}
                    {a.version.includes("rc") && <span style={badgeStyle("warn")}>PRE-RELEASE</span>}
                  </div>
                  <div style={{ fontSize: 11, color: "var(--muted-fg)", marginTop: 2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {a.summary}
                  </div>
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--muted-fg)", minWidth: 60, textAlign: "right" }}>
                  v{a.version}
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--muted-fg)", minWidth: 54, textAlign: "right" }}>
                  {a.nodes} nodes
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--muted-fg)", minWidth: 58, textAlign: "right" }}>
                  {a.size}
                </div>
                <AddonToggle on={a.enabled} onClick={(e) => { toggle(a.id); }} />
              </div>
            ))}
          </div>
        </div>

        {/* Right: detail panel */}
        <div style={{ borderLeft: "1px solid var(--border)", background: "var(--panel-bg)",
          display: "flex", flexDirection: "column", minWidth: 0 }}>
          <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--border)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: 4,
                background: "var(--node-header-bg)", border: "1px solid var(--node-card-border)",
                borderLeft: `3px solid ${catColor(focus.category)}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "var(--node-header-fg)",
              }}>
                <CatIcon cat={focus.category} />
              </div>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, color: "var(--panel-title-fg)" }}>{focus.name}</div>
                <div style={{ fontSize: 11, color: "var(--muted-fg)", fontFamily: "var(--font-mono)" }}>
                  {focus.id}
                </div>
              </div>
            </div>
          </div>
          <div style={{ overflowY: "auto", flex: 1 }}>
            <div style={sectTitle}>About</div>
            <div style={{ padding: "8px 12px", color: "var(--app-fg)", fontSize: 11.5, lineHeight: 1.5 }}>
              {focus.long}
            </div>
            <div style={sectTitle}>Details</div>
            <div style={rowsGrid}>
              <span style={l}>Vendor</span><span style={v}>{focus.vendor}</span>
              <span style={l}>Version</span><span style={v}>{focus.version}</span>
              <span style={l}>Category</span><span style={v}>{focus.cat}</span>
              <span style={l}>Install size</span><span style={v}>{focus.size}</span>
              <span style={l}>Nodes exposed</span><span style={v}>{focus.nodes}</span>
              <span style={l}>Last updated</span><span style={v}>{focus.updated}</span>
              <span style={l}>Status</span>
              <span style={v}>
                <span style={{
                  display: "inline-flex", alignItems: "center", gap: 5,
                  color: focus.enabled ? "var(--run-completed)" : "var(--muted-fg)",
                }}>
                  <DotIcon color={focus.enabled ? "var(--run-completed)" : "var(--muted-fg)"} />
                  {focus.enabled ? "Loaded into runtime" : "Disabled"}
                </span>
              </span>
            </div>
            <div style={sectTitle}>Requirements</div>
            <div style={{ padding: "6px 12px 10px" }}>
              <div style={{
                fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--app-fg)",
                background: "var(--console-bg)", border: "1px solid var(--border)",
                padding: "6px 8px", borderRadius: 3,
              }}>
                {focus.requires || "— none —"}
              </div>
              {focus.deps.length > 0 && (
                <div style={{ marginTop: 6, display: "flex", flexWrap: "wrap", gap: 4 }}>
                  {focus.deps.map(d => (
                    <span key={d} style={{
                      fontFamily: "var(--font-mono)", fontSize: 10.5, padding: "1px 6px",
                      border: "1px solid var(--border)", borderRadius: 999,
                      color: "var(--muted-fg)",
                    }}>{d}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div style={{
            borderTop: "1px solid var(--border)", padding: "8px 12px",
            display: "flex", gap: 6, background: "var(--toolbar-bg)",
          }}>
            <button style={{ ...tbBtn, flex: 1 }}>Preferences…</button>
            <button style={{ ...tbBtn, flex: 1 }}>View Nodes…</button>
            <button style={{
              ...tbBtn,
              background: focus.enabled ? "var(--inspector-danger-bg)" : "var(--accent-strong)",
              color: focus.enabled ? "var(--inspector-danger-fg)" : "#fff",
              borderColor: focus.enabled ? "var(--inspector-danger-border)" : "var(--accent-strong)",
              flex: 1,
            }}
              onClick={() => toggle(focus.id)}>
              {focus.enabled ? "Disable" : "Enable"}
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{
        background: "var(--toolbar-bg)", borderTop: "1px solid var(--border)",
        padding: "6px 12px", display: "flex", alignItems: "center", gap: 8,
      }}>
        <span style={{ color: "var(--muted-fg)", fontSize: 11 }}>
          Changes apply on next graph runtime restart. Built-in add-ons cannot be uninstalled.
        </span>
        <span style={{ flex: 1 }} />
        <button style={tbBtn}>Cancel</button>
        <button style={{ ...tbBtn, background: "var(--accent-strong)", color: "#fff", borderColor: "var(--accent-strong)" }}>
          Apply & Reload Runtime
        </button>
      </div>
    </div>
  );
}

// Inline styles reused in variant 1
const tbBtn = {
  background: "var(--panel-alt-bg)", border: "1px solid var(--border)",
  borderRadius: 3, padding: "3px 9px", color: "var(--app-fg)",
  cursor: "pointer", fontSize: 11.5, fontFamily: "var(--font-ui)",
  display: "inline-flex", alignItems: "center", gap: 5,
};
const sectTitle = {
  background: "var(--inspector-section-header-bg)", padding: "4px 12px",
  fontWeight: 600, fontSize: 11, color: "var(--muted-fg)",
  textTransform: "uppercase", letterSpacing: 0.5,
  borderBottom: "1px solid var(--border)", borderTop: "1px solid var(--border)",
};
const rowsGrid = {
  padding: "8px 12px", display: "grid",
  gridTemplateColumns: "110px 1fr", gap: "6px 10px", alignItems: "center", fontSize: 11.5,
};
const l = { color: "var(--muted-fg)" };
const v = { color: "var(--app-fg)", fontFamily: "var(--font-mono)", fontSize: 11 };

function badgeStyle(kind) {
  const colors = {
    core: { bg: "rgba(47,137,255,0.15)", fg: "var(--cat-core)", bd: "rgba(47,137,255,0.3)" },
    accent: { bg: "rgba(96,205,255,0.12)", fg: "var(--accent)", bd: "rgba(96,205,255,0.3)" },
    warn: { bg: "rgba(232,168,56,0.15)", fg: "var(--edge-warning)", bd: "rgba(232,168,56,0.3)" },
  }[kind];
  return {
    fontSize: 9.5, fontWeight: 600, letterSpacing: 0.4,
    padding: "0px 5px", borderRadius: 2,
    background: colors.bg, color: colors.fg,
    border: `1px solid ${colors.bd}`,
  };
}

Object.assign(window, { V1_SettingsDialog, AddonToggle, tbBtn, badgeStyle });
